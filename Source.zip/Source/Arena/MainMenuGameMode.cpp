﻿
#include "MainMenuGameMode.h"
#include "MainMenuWidget.h"
#include "Blueprint/UserWidget.h"
#include "Kismet/GameplayStatics.h"


AMainMenuGameMode::AMainMenuGameMode()
{
    DefaultPawnClass = nullptr;
}

void AMainMenuGameMode::BeginPlay()
{
    Super::BeginPlay();

    UE_LOG(LogTemp, Warning, TEXT("Main Menu Game Mode - BeginPlay"));

    // Get player controller
    APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
    if (!PC)
    {
        UE_LOG(LogTemp, Error, TEXT("No PlayerController!"));
        return;
    }

    // Create menu widget FIRST
    if (MainMenuWidgetClass)
    {
        MainMenuWidget = CreateWidget<UMainMenuWidget>(PC, MainMenuWidgetClass);
        if (MainMenuWidget)
        {
            MainMenuWidget->AddToViewport();
            UE_LOG(LogTemp, Log, TEXT("✓ Main Menu Widget displayed"));
        }
    }

    // IMPORTANT: Set input mode AFTER widget is created
    FInputModeUIOnly InputMode;
    InputMode.SetWidgetToFocus(MainMenuWidget->TakeWidget());
    InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);

    PC->SetInputMode(InputMode);
    PC->bShowMouseCursor = true;
    PC->bEnableClickEvents = true;
    PC->bEnableMouseOverEvents = true;

    UE_LOG(LogTemp, Warning, TEXT("✓ Input mode set to UI only"));
    UE_LOG(LogTemp, Warning, TEXT("✓ Mouse cursor enabled"));
}