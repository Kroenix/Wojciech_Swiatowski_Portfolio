#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "DamageNumberWidget.generated.h"

UCLASS()
class ARENA_API UDamageNumberWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    // Call this right after spawning to set the text and color
    UFUNCTION(BlueprintCallable, Category = "Damage")
    void SetDamage(float DamageAmount);

    // Current opacity � ADamageNumber drives this every tick
    UPROPERTY(BlueprintReadWrite, Category = "Damage")
    float Opacity = 1.0f;

protected:
    UPROPERTY(BlueprintReadOnly, meta = (BindWidget))
    class UTextBlock* DamageText;
};