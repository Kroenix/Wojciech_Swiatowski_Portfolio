
#include "WeaponSniperRifle.h"
#include "UObject/ConstructorHelpers.h"

AWeaponSniperRifle::AWeaponSniperRifle()
{
    WeaponName = "AWP";
    FireRate = 1.5f;         // Slow fire rate
    Damage = 50.0f;          // High damage per pellet
    ProjectilesPerShot = 1;  // Shoots 8 pellets
    SpreadAngle = 0.0f;     // Wide spread
    MaxAmmo = 40;

    // Load a cube as shotgun mesh
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube"));
    if (CubeMesh.Succeeded())
    {
        WeaponMesh->SetStaticMesh(CubeMesh.Object);
        WeaponMesh->SetRelativeScale3D(FVector(1.0f, 0.2f, 0.2f));
    }
}
