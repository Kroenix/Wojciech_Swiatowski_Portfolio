
#include "WeaponAK47.h"
#include "UObject/ConstructorHelpers.h"

AWeaponAK47::AWeaponAK47()
{
    WeaponName = "AK-47";
    FireRate = 0.1f;        // 10 shots per second (fast)
    Damage = 8.0f;          // Less damage per shot
    ProjectilesPerShot = 1;
    SpreadAngle = 1.0f;// Very accurate
    MaxAmmo = 80;

    // Load a cube as rifle mesh
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube"));
    if (CubeMesh.Succeeded())
    {
        WeaponMesh->SetStaticMesh(CubeMesh.Object);
        WeaponMesh->SetRelativeScale3D(FVector(0.8f, 0.15f, 0.15f));
    }
}
