#include "DamageNumberWidget.h"
#include "Components/TextBlock.h"

void UDamageNumberWidget::SetDamage(float DamageAmount)
{
    if (!DamageText) return;

    // Set text
    FString DamageString = FString::Printf(TEXT("%.0f"), DamageAmount);
    DamageText->SetText(FText::FromString(DamageString));

    // Color based on damage amount
    // Small: white | Medium: yellow | Large: orange
    FLinearColor TextColor;

    if (DamageAmount >= 25.0f)
    {
        TextColor = FLinearColor(1.0f, 0.3f, 0.0f, 1.0f); // Orange � heavy hit
    }
    else if (DamageAmount >= 10.0f)
    {
        TextColor = FLinearColor(1.0f, 1.0f, 0.0f, 1.0f); // Yellow � medium hit
    }
    else
    {
        TextColor = FLinearColor(1.0f, 1.0f, 1.0f, 1.0f); // White � light hit
    }

    DamageText->SetColorAndOpacity(FSlateColor(TextColor));
}