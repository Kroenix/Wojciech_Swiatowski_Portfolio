
#include "EnemyFast.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"

AEnemyFast::AEnemyFast()
{
    // Stats
    MaxHealth = 50.0f;
    MoveSpeed = 600.0f;
    AttackDamage = 7.0f;
    AttackCooldown = 0.7f;
    ScoreValue = 75;

    // Blue � distinct from base red
    // BeginPlay will apply this to BodyMaterialInstance
    EnemyColor = FLinearColor(0.0f, 0.4f, 1.0f, 1.0f);

    // Slightly narrower capsule
    GetCapsuleComponent()->SetCapsuleHalfHeight(50.0f);
    GetCapsuleComponent()->SetCapsuleRadius(28.0f);
}
