
#include "MainMenuWidget.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "ArenaGameInstance.h"

void UMainMenuWidget::NativeConstruct()
{
    Super::NativeConstruct();

    // Manually find widgets by name
    StartButton = Cast<UButton>(GetWidgetFromName(TEXT("StartButton")));
    QuitButton = Cast<UButton>(GetWidgetFromName(TEXT("QuitButton")));
    TitleText = Cast<UTextBlock>(GetWidgetFromName(TEXT("TitleText")));

    // Debug
    UE_LOG(LogTemp, Warning, TEXT("=== MainMenu Widget Debug ==="));
    UE_LOG(LogTemp, Warning, TEXT("StartButton valid? %s"), StartButton ? TEXT("YES") : TEXT("NO"));
    UE_LOG(LogTemp, Warning, TEXT("QuitButton valid? %s"), QuitButton ? TEXT("YES") : TEXT("NO"));
    UE_LOG(LogTemp, Warning, TEXT("TitleText valid? %s"), TitleText ? TEXT("YES") : TEXT("NO"));

    // Bind buttons
    if (StartButton)
    {
        StartButton->OnClicked.AddDynamic(this, &UMainMenuWidget::OnStartClicked);
    }

    if (QuitButton)
    {
        QuitButton->OnClicked.AddDynamic(this, &UMainMenuWidget::OnQuitClicked);
    }

    if (TitleText)
    {
        TitleText->SetText(FText::FromString(TEXT("ARENA SHOOTER")));
    }
}

void UMainMenuWidget::OnStartClicked()
{
    UE_LOG(LogTemp, Warning, TEXT("START BUTTON CLICKED"));

    APlayerController* PC = GetOwningPlayer();
    if (!PC)
    {
        UGameplayStatics::OpenLevel(this, FName("ArenaMap"));
        return;
    }

    // STEP 1: Hide this menu immediately
    this->SetVisibility(ESlateVisibility::Hidden);
    UE_LOG(LogTemp, Warning, TEXT("Menu hidden"));

    // STEP 2: Start fade to black (longer duration)
    if (PC->PlayerCameraManager)
    {
        PC->PlayerCameraManager->StartCameraFade(
            0.0f,  // From clear
            1.0f,  // To black
            1.5f,  // 1 second (was 0.5, now slower)
            FLinearColor::Black,
            false,
            true   // Hold at black
        );
        UE_LOG(LogTemp, Warning, TEXT("Fading to black..."));
    }

    // STEP 3: Wait for fade to complete, THEN load level
    FTimerHandle LoadTimer;
    GetWorld()->GetTimerManager().SetTimer(LoadTimer, [this]()
        {
            UE_LOG(LogTemp, Warning, TEXT("Loading level..."));
            UGameplayStatics::OpenLevel(this, FName("ArenaMap"));

        }, 2.2f, false); // Wait 1.2 seconds (fade duration + buffer)
}

void UMainMenuWidget::OnQuitClicked()
{
    UE_LOG(LogTemp, Warning, TEXT("Quit Button Clicked!"));

    
    APlayerController* PC = GetOwningPlayer();


    if (PC)
    {
        UKismetSystemLibrary::QuitGame(GetWorld(), PC, EQuitPreference::Quit, false);
    }
}

void UMainMenuWidget::LoadGameLevel()
{
    UE_LOG(LogTemp, Warning, TEXT("Loading game level..."));

    // Get game instance
    UArenaGameInstance* GameInstance = Cast<UArenaGameInstance>(GetGameInstance());
    if (GameInstance)
    {
        // Load with fade
        GameInstance->LoadLevelWithFade(FName("ArenaMap"), 1.0f);
    }
    else
    {
        // Fallback: direct load
        UGameplayStatics::OpenLevel(this, FName("ArenaMap"));
    }
}