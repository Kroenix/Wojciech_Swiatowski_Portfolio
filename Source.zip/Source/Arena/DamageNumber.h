#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "DamageNumber.generated.h"

UCLASS()
class ARENA_API ADamageNumber : public AActor
{
	GENERATED_BODY()
	
public:
    ADamageNumber();
    virtual void Tick(float DeltaTime) override;

    // Called by EnemyBase after spawning
    void SetDamageText(float DamageAmount);

    // Widget class � assign WBP_DamageNumber in Blueprint
    UPROPERTY(EditDefaultsOnly, Category = "Damage")
    TSubclassOf<class UDamageNumberWidget> DamageWidgetClass;

private:
    UPROPERTY(VisibleAnywhere)
    class UWidgetComponent* WidgetComponent;

    // How long the number stays visible
    UPROPERTY(EditDefaultsOnly, Category = "Damage")
    float Lifetime = 1.2f;

    // How fast it floats upward
    UPROPERTY(EditDefaultsOnly, Category = "Damage")
    float FloatSpeed = 80.0f;

    float ElapsedTime = 0.0f;

    UPROPERTY()
    class UDamageNumberWidget* DamageWidget;
};