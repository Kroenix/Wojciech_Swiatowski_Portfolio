// Fill out your copyright notice in the Description page of Project Settings.


#include "WeaponShotgun.h"
#include "UObject/ConstructorHelpers.h"

AWeaponShotgun::AWeaponShotgun()
{
    WeaponName = "Shotgun";
    FireRate = 0.8f;         // Slow fire rate
    Damage = 12.0f;          // High damage per pellet
    ProjectilesPerShot = 8;  // Shoots 8 pellets
    SpreadAngle = 15.0f;     // Wide spread
    MaxAmmo = 60;

    // Load a cube as shotgun mesh
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube"));
    if (CubeMesh.Succeeded())
    {
        WeaponMesh->SetStaticMesh(CubeMesh.Object);
        WeaponMesh->SetRelativeScale3D(FVector(1.0f, 0.2f, 0.2f));
    }
}
