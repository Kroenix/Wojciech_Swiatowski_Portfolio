
#include "WeaponUmp.h"
#include "UObject/ConstructorHelpers.h"

AWeaponUmp::AWeaponUmp()
{
    WeaponName = "UMP";
    FireRate = 0.2f;        // 5 shots per second (mid)
    Damage = 12.0f;          // Less damage per shot
    ProjectilesPerShot = 1;
    SpreadAngle = 3.0f;     // Very accurate
    MaxAmmo = 120;

    // Load a cube as rifle mesh
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube"));
    if (CubeMesh.Succeeded())
    {
        WeaponMesh->SetStaticMesh(CubeMesh.Object);
        WeaponMesh->SetRelativeScale3D(FVector(0.8f, 0.15f, 0.15f));
    }
}
