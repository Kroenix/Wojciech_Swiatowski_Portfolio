// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnemyBase.h"
#include "EnemyFast.generated.h"

/**
 * 
 */
UCLASS()
class ARENA_API AEnemyFast : public AEnemyBase
{
	GENERATED_BODY()
	

public:
	AEnemyFast();
};
