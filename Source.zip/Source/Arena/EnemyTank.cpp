// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyTank.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"

AEnemyTank::AEnemyTank()
{
    // Stats
    MaxHealth = 300.0f;
    MoveSpeed = 150.0f;
    AttackDamage = 25.0f;
    AttackCooldown = 2.0f;
    ScoreValue = 300;

    // Dark maroon � distinct from base red
    EnemyColor = FLinearColor(0.35f, 0.0f, 0.0f, 1.0f);

    // Wider capsule � feels heavy
    GetCapsuleComponent()->SetCapsuleHalfHeight(50.0f);
    GetCapsuleComponent()->SetCapsuleRadius(55.0f);
}
