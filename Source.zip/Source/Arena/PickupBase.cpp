#include "PickupBase.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "MyArenaCharacter.h"
#include "Kismet/GameplayStatics.h"

APickupBase::APickupBase()
{
    PrimaryActorTick.bCanEverTick = true;

    // Create collision sphere
    CollisionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("CollisionSphere"));
    RootComponent = CollisionSphere;
    CollisionSphere->SetSphereRadius(50.0f);
    CollisionSphere->SetCollisionProfileName(TEXT("OverlapAllDynamic"));

    // Create mesh
    PickupMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PickupMesh"));
    PickupMesh->SetupAttachment(CollisionSphere);
    PickupMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);

    // Load cube mesh as default
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube"));
    if (CubeMesh.Succeeded())
    {
        PickupMesh->SetStaticMesh(CubeMesh.Object);
        PickupMesh->SetWorldScale3D(FVector(0.5f));
    }
}

void APickupBase::BeginPlay()
{
    Super::BeginPlay();

    StartLocation = GetActorLocation();

    // Setup overlap event
    CollisionSphere->OnComponentBeginOverlap.AddDynamic(this, &APickupBase::OnOverlapBegin);

    // Create dynamic material
    if (PickupMesh)
    {
        DynamicMaterial = PickupMesh->CreateDynamicMaterialInstance(0);
        if (DynamicMaterial)
        {
            DynamicMaterial->SetVectorParameterValue(FName("Color"), PickupColor);
        }
    }
}

void APickupBase::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    // Rotation
    if (bRotate)
    {
        FRotator NewRotation = GetActorRotation();
        NewRotation.Yaw += RotationSpeed * DeltaTime;
        SetActorRotation(NewRotation);
    }

    // Bob up and down
    if (bBobUpDown)
    {
        BobTime += DeltaTime * BobSpeed;
        float ZOffset = FMath::Sin(BobTime) * BobAmount;
        FVector NewLocation = StartLocation + FVector(0.0f, 0.0f, ZOffset);
        SetActorLocation(NewLocation);
    }
}

void APickupBase::OnOverlapBegin(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
    UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    AMyArenaCharacter* Character = Cast<AMyArenaCharacter>(OtherActor);
    if (Character)
    {
        // Call virtual function (overridden in child classes)
        OnPickedUp(Character);

        // Play sound
        if (PickupSound)
        {
            UGameplayStatics::PlaySoundAtLocation(this, PickupSound, GetActorLocation());
        }

        // Destroy pickup
        Destroy();
    }
}

void APickupBase::OnPickedUp(AMyArenaCharacter* Character)
{
    // Override this in child classes
    UE_LOG(LogTemp, Log, TEXT("Pickup collected"));
}