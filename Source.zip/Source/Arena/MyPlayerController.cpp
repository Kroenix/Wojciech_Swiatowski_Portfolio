
#include "MyPlayerController.h"
#include "MyGameMode.h"

AMyPlayerController::AMyPlayerController()
{
	bShowMouseCursor = true;
	bEnableClickEvents = true;
	bEnableMouseOverEvents = true;
}

void AMyPlayerController::BeginPlay()
{
    Super::BeginPlay();

    // Check if we're in the game (not main menu)
    AMyGameMode* GameMode = Cast<AMyGameMode>(GetWorld()->GetAuthGameMode());
    if (GameMode)
    {
        // We're in the game level - set game input mode
        UE_LOG(LogTemp, Warning, TEXT("Game Level - Setting Game Input Mode"));

        FInputModeGameAndUI InputMode;
        InputMode.SetHideCursorDuringCapture(false);
        InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
        SetInputMode(InputMode);

        bShowMouseCursor = true;
        bEnableClickEvents = true;
        bEnableMouseOverEvents = true;

        UE_LOG(LogTemp, Log, TEXT("? Game input mode enabled"));
    }
    else
    {
        // We're probably in main menu
        UE_LOG(LogTemp, Log, TEXT("Not in game level (probably main menu)"));
    }
}
